package addressBook.exception;

public class AddressBookException extends Exception {

    public AddressBookException(String s) {
        super(s);
    }
}
