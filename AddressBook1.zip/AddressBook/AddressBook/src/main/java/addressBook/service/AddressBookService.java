package addressBook.service;

import java.util.Set;
import addressBook.exception.AddressBookException;
import addressBook.model.AddressBook;
import addressBook.model.Contact;

public interface AddressBookService {

    void add(AddressBook addressBook, Contact contact) throws AddressBookException;

    void remove(AddressBook addressBook, Contact contact) throws AddressBookException;

    Set<Contact> getAllContacts(AddressBook addressBook);

    void printContacts(AddressBook addressBook);


}
