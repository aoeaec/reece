package addressBook.service.impl;

import java.util.HashSet;
import java.util.Set;
import addressBook.model.AddressBook;
import addressBook.model.Contact;
import addressBook.model.User;
import addressBook.service.PrintService;

public class ConsolePrintServiceImpl implements PrintService {

    @Override
    public void printAllUniqueContacts(User user) {
        System.out.println(mergeAndReturnContacts(user));
    }

    @Override
    public void printContactsForAddressBook(User user, String nameOfAddressBook) {
        user.getAddressBooks().stream()
            .filter(it -> it.getName().equalsIgnoreCase(nameOfAddressBook))
            .forEach(it -> {
                System.out.println(it.getName());
                System.out.println(it.getContacts());
            });
    }

    @Override
    public Set<Contact> mergeAndReturnContacts(User user) {
        Set<Contact> union = new HashSet<>();
        for (AddressBook anAddressBook : user.getAddressBooks()) {
            union.addAll(anAddressBook.getContacts());
        }
        return union;
    }

}
