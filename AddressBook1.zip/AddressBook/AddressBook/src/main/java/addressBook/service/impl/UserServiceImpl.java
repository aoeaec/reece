package addressBook.service.impl;

import addressBook.model.AddressBook;
import addressBook.model.User;

public class UserServiceImpl implements addressBook.service.UserService {

    @Override
    public void addAddressBook(User user, AddressBook addressBook) {
        user.getAddressBooks().add(addressBook);
    }

}
