package addressBook.service.impl;

import addressBook.exception.AddressBookException;
import addressBook.model.AddressBook;
import addressBook.model.Contact;
import addressBook.service.AddressBookService;
import addressBook.validator.ContactValidator;

import java.util.Set;

public class AddressBookServiceImpl implements AddressBookService {

    private ContactValidator contactValidator = new ContactValidator();

    public void add(AddressBook addressBook, Contact contact) throws AddressBookException {
        if (!addressBook.getContacts().contains(contact)) {
            addressBook.addContact(contact);
        } else
            throw new AddressBookException("Contact" + contact + " is already in Address Book " + addressBook.getName());
    }

    public void remove(AddressBook addressBook, Contact contact) throws AddressBookException {
        if (addressBook.getContacts().contains(contact)) {
            addressBook.getContacts().remove(contact);
        } else throw new AddressBookException("Contact" + contact + " not is Address Book " + addressBook.getName());
    }

    public Set<Contact> getAllContacts(AddressBook addressBook) {
        return addressBook.getContacts();
    }

    public void printContacts(AddressBook addressBook) {
        addressBook.getContacts().forEach(System.out::println);
    }


}
