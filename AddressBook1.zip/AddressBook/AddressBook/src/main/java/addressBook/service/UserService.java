package addressBook.service;

import addressBook.model.AddressBook;
import addressBook.model.User;

public interface UserService {
    void addAddressBook(User user, AddressBook addressBook);
}
