package addressBook.service;

import addressBook.model.Contact;
import addressBook.model.User;

import java.util.Set;

public interface PrintService {

    void printAllUniqueContacts(User user);

    void printContactsForAddressBook(User user, String nameOfTheAddressBook);

    Set<Contact> mergeAndReturnContacts(User user);

}
