package addressBook.validator;

import addressBook.exception.AddressBookException;

public class ContactValidator {

    final static String PHONE_REGEX = "^([0-9\\-]?){5,15}[0-9]$";
    final static String NAME_REGEX = "^[a-zA-Z '.-]*$";

    public static boolean validateContactNumber(String phoneNumber) throws AddressBookException {
        if (phoneNumber != null && phoneNumber.matches(PHONE_REGEX)) {
            return true;
        } else {
            throw new AddressBookException("Contact number is invalid " + phoneNumber);
        }
    }

    public static boolean validateName(String name) throws AddressBookException {
        if (name != null && name.matches(NAME_REGEX)) {
            return true;
        } else {
            throw new AddressBookException("Name is invalid " + name);
        }
    }
}
