package addressBook.model;

import java.util.HashSet;
import java.util.Set;

public class User {

    private final Set<AddressBook> addressBooks = new HashSet<>();

    public Set<AddressBook> getAddressBooks() {
        return addressBooks;
    }
}
