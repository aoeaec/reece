package addressBook.model;

import addressBook.exception.AddressBookException;
import addressBook.validator.ContactValidator;

public class Contact {

    private String name;
    private String contactNumber;

    public Contact(String name, String contactNumber) throws AddressBookException {
        ContactValidator.validateName(name);
        ContactValidator.validateContactNumber(contactNumber);
        this.name = name;
        this.contactNumber = contactNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 31 * hash + (this.name != null ? this.name.hashCode() : 0);
        hash = 31 * hash + (this.contactNumber != null ? this.contactNumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }

        if (obj.getClass() != this.getClass()) {
            return false;
        }

        final Contact other = (Contact) obj;
        if ((this.name == null) ? (other.name != null) : !this.name.equals(other.name)) {
            return false;
        }

        if (this.contactNumber != other.contactNumber) {
            return false;
        }

        return true;
    }

    @Override
    public String toString() {
        StringBuilder buf = new StringBuilder("Name: ");
        buf.append(name);
        buf.append(", Contact Number : ");
        buf.append(contactNumber);
        return buf.toString();
    }
}
