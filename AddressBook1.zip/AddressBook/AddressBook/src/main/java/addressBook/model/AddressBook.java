package addressBook.model;

import java.util.HashSet;
import java.util.Set;

public class AddressBook {
    private String name;
    private Set<Contact> contacts;

    public AddressBook(String name) {
        this.name = name;
        this.contacts = new HashSet<>();
    }

    public Set<Contact> getContacts() {
        return contacts;
    }

    public void setContacts(Set<Contact> contacts) {
        this.contacts = contacts;
    }

    public void addContact(Contact contact) {
        contacts.add(contact);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
