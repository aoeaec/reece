package addressBook.service.impl;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import addressBook.exception.AddressBookException;
import addressBook.model.AddressBook;
import addressBook.model.Contact;
import addressBook.model.User;
import addressBook.service.PrintService;

public class ConsolePrintServiceImplTest {

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private AddressBook addressBook1;
    private AddressBook addressBook2;
    private Contact contact1;
    private Contact contact2;
    private Contact contact3;
    private Contact contact4;
    private Contact contact5;
    private Contact contact6;
    private PrintService printService;
    private User user1;

    @Before
    public void initialize() throws AddressBookException {
        printService = new ConsolePrintServiceImpl();
        addressBook1 = new AddressBook("Address Book 1");
        addressBook2 = new AddressBook("Address Book 2");
        contact1 = new Contact("Andrew", "1234567");
        contact2 = new Contact("Alex", "88997709");
        contact3 = new Contact("Bob", "2356734");
        contact4 = new Contact("Cathy", "00987654");
        contact5 = new Contact("Diaene", "76765456");
        contact6 = new Contact("Jack", "123123123");
        user1 = new User();
        System.setOut(new PrintStream(outContent));
    }

    @After
    public void restoreStreams() {

        addressBook1.setContacts(null);
        addressBook1.setName(null);
        addressBook2.setContacts(null);
        addressBook2.setName(null);
        System.setOut(originalOut);
    }

    @Test
    public void printAllUniqueContacts() {

        addressBook1.addContact(contact1);
        addressBook1.addContact(contact2);
        addressBook1.addContact(contact3);
        addressBook1.addContact(contact4);
        addressBook1.addContact(contact5);

        addressBook2.addContact(contact4);
        addressBook2.addContact(contact5);
        addressBook2.addContact(contact6);

        user1.getAddressBooks().add(addressBook1);
        user1.getAddressBooks().add(addressBook2);

        assertEquals(2, user1.getAddressBooks().size());

        printService.printAllUniqueContacts(user1);

        assertEquals(("[Name: Andrew, Contact Number : 1234567, " +
                "Name: Cathy, Contact Number : 00987654, " +
                "Name: Bob, Contact Number : 2356734, " +
                "Name: Alex, Contact Number : 88997709, " +
                "Name: Diaene, Contact Number : 76765456, " +
                "Name: Jack, Contact Number : 123123123]").trim()
            , outContent.toString().trim().replace("\r", ""));

    }

    @Test
    public void printContactsForAddressBook() {
        addressBook1.addContact(contact1);
        addressBook1.addContact(contact2);
        addressBook1.addContact(contact3);
        addressBook1.addContact(contact4);
        addressBook1.addContact(contact5);

        addressBook2.addContact(contact4);
        addressBook2.addContact(contact5);
        addressBook2.addContact(contact6);

        user1.getAddressBooks().add(addressBook1);
        user1.getAddressBooks().add(addressBook2);

        assertEquals(2, user1.getAddressBooks().size());

        printService.printContactsForAddressBook(user1, "Address Book 1");

        assertEquals(("Address Book 1\n" +
                "[Name: Andrew, Contact Number : 1234567, " +
                "Name: Cathy, Contact Number : 00987654, " +
                "Name: Bob, Contact Number : 2356734, " +
                "Name: Alex, Contact Number : 88997709, " +
                "Name: Diaene, Contact Number : 76765456]").trim()
            , outContent.toString().trim().replace("\r", ""));
    }

    @Test
    public void mergeAndReturnContactsTest() {

        addressBook1.addContact(contact1);
        addressBook1.addContact(contact2);
        addressBook1.addContact(contact3);
        addressBook1.addContact(contact4);
        addressBook1.addContact(contact5);

        addressBook2.addContact(contact4);
        addressBook2.addContact(contact5);
        addressBook2.addContact(contact6);

        user1.getAddressBooks().add(addressBook1);
        user1.getAddressBooks().add(addressBook2);

        assertEquals(2, user1.getAddressBooks().size());

        Set<Contact> contacts = printService.mergeAndReturnContacts(user1);

        assertEquals(6, contacts.size());
        assertTrue(contacts.contains(contact1));
        assertTrue(contacts.contains(contact2));
        assertTrue(contacts.contains(contact3));
        assertTrue(contacts.contains(contact4));
        assertTrue(contacts.contains(contact5));
        assertTrue(contacts.contains(contact6));

    }
}