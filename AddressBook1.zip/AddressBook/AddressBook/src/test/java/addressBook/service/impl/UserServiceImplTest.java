package addressBook.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import addressBook.exception.AddressBookException;
import addressBook.model.AddressBook;
import addressBook.model.Contact;
import addressBook.model.User;
import addressBook.service.UserService;

public class UserServiceImplTest {
    private AddressBook addressBook1;
    private AddressBook addressBook2;
    private AddressBook addressBook3;
    private Contact contact1;
    private Contact contact2;
    private Contact contact3;
    private Contact contact4;
    private Contact contact5;
    private Contact contact6;
    private Contact contact7;
    private UserService userService;
    private User user1;
    private User user2;

    @Before
    public void initialize() throws AddressBookException {
        userService = new UserServiceImpl();
        addressBook1 = new AddressBook("Address Book 1");
        addressBook2 = new AddressBook("Address Book 2");
        addressBook3 = new AddressBook("Address Book 3");
        contact1 = new Contact("Andrew", "1234567");
        contact2 = new Contact("Alex", "88997709");
        contact3 = new Contact("Bob", "2356734");
        contact4 = new Contact("Cathy", "00987654");
        contact5 = new Contact("Diaene", "76765456");
        contact6 = new Contact("Jack", "123123123");
        contact7 = new Contact("Fredo", "99887766");
        user1 = new User();
        user2 = new User();

    }

    @Test
    public void addAddressBook() {

        addressBook1.addContact(contact1);
        addressBook1.addContact(contact2);
        addressBook1.addContact(contact3);
        addressBook1.addContact(contact4);
        addressBook1.addContact(contact5);
        addressBook1.addContact(contact6);
        addressBook1.addContact(contact7);

        addressBook2.addContact(contact4);
        addressBook2.addContact(contact5);
        addressBook2.addContact(contact6);


        addressBook3.addContact(contact5);
        addressBook3.addContact(contact6);
        addressBook3.addContact(contact7);

        assertEquals(0, user1.getAddressBooks().size());
        assertEquals(0, user2.getAddressBooks().size());

        userService.addAddressBook(user1, addressBook1);
        userService.addAddressBook(user1, addressBook2);

        userService.addAddressBook(user2, addressBook1);
        userService.addAddressBook(user2, addressBook3);

        assertEquals(2, user1.getAddressBooks().size());
        assertTrue(user1.getAddressBooks().contains(addressBook1));
        assertTrue(user1.getAddressBooks().contains(addressBook2));

        assertEquals(2, user2.getAddressBooks().size());
        assertTrue(user2.getAddressBooks().contains(addressBook1));
        assertTrue(user2.getAddressBooks().contains(addressBook3));

    }
}