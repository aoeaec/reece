package addressBook.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Set;
import org.junit.Before;
import org.junit.Test;
import addressBook.exception.AddressBookException;
import addressBook.model.AddressBook;
import addressBook.model.Contact;
import addressBook.service.AddressBookService;

public class AddressBookServiceImplTest {
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private AddressBook addressBook1;
    private AddressBook addressBook2;
    private Contact contact1;
    private Contact contact2;
    private Contact contact3;
    private Contact contact4;
    private Contact contact5;
    private Contact contact6;
    private Contact contact7;
    private AddressBookService addressBookService;

    @Before
    public void initialize() throws AddressBookException {
        addressBookService = new AddressBookServiceImpl();
        addressBook1 = new AddressBook("Address Book 1");
        addressBook2 = new AddressBook("Address Book 2");
        contact1 = new Contact("Andrew", "1234567");
        contact2 = new Contact("Alex", "88997709");
        contact3 = new Contact("Bob", "2356734");
        contact4 = new Contact("Cathy", "00987654");
        contact5 = new Contact("Diaene", "76765456");
        contact6 = new Contact("Jack", "123123123");
        contact7 = new Contact("Fredo", "9988-7766");

    }

    @Test
    public void addContactSingleAddressBook() throws AddressBookException {

        assertEquals(0, addressBook1.getContacts().size());

        addressBookService.add(addressBook1, contact1);
        addressBookService.add(addressBook1, contact2);
        addressBookService.add(addressBook1, contact3);
        addressBookService.add(addressBook1, contact4);

        assertEquals(4, addressBook1.getContacts().size());
    }

    @Test
    public void addContactMultipleAddressBook() throws AddressBookException {

        assertEquals(0, addressBook1.getContacts().size());
        assertEquals(0, addressBook2.getContacts().size());

        addressBookService.add(addressBook1, contact1);
        addressBookService.add(addressBook1, contact2);
        addressBookService.add(addressBook1, contact3);
        addressBookService.add(addressBook1, contact4);

        addressBookService.add(addressBook2, contact5);
        addressBookService.add(addressBook2, contact6);

        assertEquals(4, addressBook1.getContacts().size());
        assertEquals(2, addressBook2.getContacts().size());
    }

    @Test
    public void removeContactMultipleAddressBook() throws AddressBookException {

        addressBook1.addContact(contact1);
        addressBook1.addContact(contact2);
        addressBook1.addContact(contact3);
        addressBook1.addContact(contact4);

        addressBookService.add(addressBook2, contact5);
        addressBookService.add(addressBook2, contact6);


        assertTrue(addressBook1.getContacts().contains(contact1));
        assertTrue(addressBook2.getContacts().contains(contact5));

        addressBookService.remove(addressBook1, contact1);
        addressBookService.remove(addressBook2, contact5);

        assertEquals(3, addressBook1.getContacts().size());
        assertFalse(addressBook1.getContacts().contains(contact1));

        assertEquals(1, addressBook2.getContacts().size());
        assertFalse(addressBook2.getContacts().contains(contact5));

    }

    @Test
    public void removeContactSingleAddressBook() throws AddressBookException {

        addressBook1.addContact(contact1);
        addressBook1.addContact(contact2);
        addressBook1.addContact(contact3);
        addressBook1.addContact(contact4);
        assertEquals(4, addressBook1.getContacts().size());
        assertTrue(addressBook1.getContacts().contains(contact1));

        addressBookService.remove(addressBook1, contact1);

        assertEquals(3, addressBook1.getContacts().size());
        assertFalse(addressBook1.getContacts().contains(contact1));

    }

    @Test
    public void getAllContactsForAnAddressBook() {

        addressBook1.addContact(contact1);
        addressBook1.addContact(contact2);
        addressBook1.addContact(contact3);
        addressBook1.addContact(contact4);
        addressBook1.addContact(contact5);
        addressBook1.addContact(contact6);
        addressBook1.addContact(contact7);

        addressBook2.addContact(contact4);
        addressBook2.addContact(contact5);
        addressBook2.addContact(contact6);

        Set<Contact> addressBook1Contacts = addressBookService.getAllContacts(addressBook1);
        Set<Contact> addressBook2Contacts = addressBookService.getAllContacts(addressBook2);

        assertEquals(7, addressBook1Contacts.size());
        assertTrue(addressBook1Contacts.contains(contact1));
        assertTrue(addressBook1Contacts.contains(contact2));
        assertTrue(addressBook1Contacts.contains(contact3));
        assertTrue(addressBook1Contacts.contains(contact4));
        assertTrue(addressBook1Contacts.contains(contact5));
        assertTrue(addressBook1Contacts.contains(contact6));
        assertTrue(addressBook1Contacts.contains(contact7));

        assertEquals(3, addressBook2Contacts.size());
        assertTrue(addressBook2Contacts.contains(contact4));
        assertTrue(addressBook2Contacts.contains(contact5));
        assertTrue(addressBook2Contacts.contains(contact6));

    }

    @Test
    public void printContactsForAnAddressBook() {
        System.setOut(new PrintStream(outContent));
        addressBook1.addContact(contact1);
        addressBook1.addContact(contact2);
        addressBook1.addContact(contact3);

        addressBookService.printContacts(addressBook1);
        assertEquals("Name: Andrew, Contact Number : 1234567\n" +
                "Name: Bob, Contact Number : 2356734\n" +
                "Name: Alex, Contact Number : 88997709".trim()
            , outContent.toString().trim().replace("\r", ""));
    }

    @Test(expected = AddressBookException.class)
    public void removeInvalidContactThrowException() throws AddressBookException {

        addressBook1.addContact(contact1);
        addressBook1.addContact(contact2);
        addressBook1.addContact(contact3);

        addressBookService.remove(addressBook1, contact7);
    }

    @Test(expected = AddressBookException.class)
    public void addInvalidContactNumberThrowException() throws AddressBookException {
        contact1 = new Contact("Andrew", "123%^4567");
    }

    @Test(expected = AddressBookException.class)
    public void addNullContactNumberThrowException() throws AddressBookException {
        contact1 = new Contact(null, "1234567");
    }
}