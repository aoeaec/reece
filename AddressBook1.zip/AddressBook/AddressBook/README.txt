AddresssBook. This addressbook maintains collection of contacts.


________About the software__________ 

This software is totally written in Java and requires a user to Install a latest version of JDK and minimum jdk version required is jdk 1.8. The build tool is Maven 3.0.5.
High level functionalities :
	Address book holds name and phone numbers of contact entries
	Users are able to add new contact entries
	Users are able to remove existing contact entries
	Users are able to print all contacts in an address book
	Users are able to maintain multiple address books
	Users are to print a unique set of all contacts across multiple address books


_Pre-requisites_ 

1 - Minimum version JDK 1.8(if you don't have JDK then get the latest version from the Oracle site) 
2 - 128 MB RAM 
3 - Pentium IV CPU (Now-a-days its an old age processor you don't need to worry about it.) 

4 - Minimum version of Maven required is 3.0.5. This could be found on Apache Maven website.

____Features____ 
1 - Works on Mac, Windows and Linux.(Tested and ran successfully) 
2 - Simplistic, easy to install using Maven build tool.
3 - Cross Platform software(as shown in above) 
4 - Shows the process output in the console area. 
5 - Its a free software (I'm releasing it under Creative Commons Attribution-NonCommercial 4.0 International License.) 

__Installation__


1. Import the project in the IDE ( IntelliJ recommended) as a maven project.

2. Traverse to main folder and run command "mvn install"



__Running Application__

1. Please refer to provided test cases.




__Plan for next release__

1. Provide GUI for entering operator and operands.

